		document.addEventListener('DOMContentLoaded', function() {
  			window.startZxing();
			parent.c3_callFunction("OnMarkerClose", ["param1", "param2"]);
		});

function startZxing(){
};